This dataset lives in: https://www.tagtog.com/Mathilde/Test_oligosaccharides

This zip was generated with:
  * date: _2023-02-07T09:04:08.364Z_
  * search: `folder:0`
  * total found documents: **15**

The dataset is here written in the [anndoc format](https://docs.tagtog.com/anndoc.html). Use the `annotations-legend.json` file to help you interpret the annotations.


What great things will you do with the dataset? :-) Enjoy!
